---
id: fc_what_is_ml_001
topic: machine_learning
category: foundations
difficulty: beginner
question_type: [what]
---

## What is Machine Learning?

Machine Learning (ML) is a field of computer science in which systems learn patterns from data to make predictions or decisions without being explicitly programmed.

Instead of relying on fixed rules, machine learning models infer rules automatically from examples.
